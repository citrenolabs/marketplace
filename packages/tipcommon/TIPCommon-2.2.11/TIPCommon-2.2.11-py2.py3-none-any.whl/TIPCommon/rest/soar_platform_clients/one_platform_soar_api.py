"""Provides the 1P API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests
    from TIPCommon.types import ChronicleSOAR, SingleJson


class OnePlatformSoarApi(BaseSoarApi):
    """Chronicle SOAR API client using 1P endpoints."""

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using 1P API."""
        payload = {
            "caseAttachment": {
                "attachmentId": 0,
                "attachmentBase64": self.params.base64_blob,
                "fileType": self.params.file_type,
                "fileName": self.params.name,
            },
            "comment": self.params.description,
            "isImportant": self.params.is_important,
        }
        if getattr(self.chronicle_soar, "alert_id", None):
            payload["alertIdentifier"] = self.chronicle_soar.alert_id

        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/comments"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using 1P API."""
        payload = {
            "identifier": self.params.entity_identifier,
            "type": self.params.entity_type,
            "environment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        endpoint = "api/1p/external/v1.0/uniqueEntities:fetchFull"
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using 1P API."""
        case_type = self.params.case_type
        if case_type == "alert":
            endpoint = (
                f"api/1p/external/v1.0/cases/{self.params.case_id}/alerts?$expand=*"
            )
        else:
            endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}?$expand=*"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_case_insights(self) -> requests.Response:
        """Get case insights using 1P API."""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/activities"
        query_params = {"filter": 'activityType="CaseInsight"'}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_installed_integrations_of_environment(self) -> requests.Response:
        """Get installed integrations of environment using legacy API."""
        endpoint = (
            f"api/1p/external/v1/integrations/{self.params.integration_identifier}/"
            "integrationInstances"
        )
        name = (
            "*"
            if self.params.environment == "Shared Instances"
            else self.params.environment
        )
        params = {"filter": f'environment="{name}"'}
        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def get_connector_cards(self) -> requests.Response:
        """Get connector cards using legacy API"""
        endpoint = (
            f"api/1p/external/v1/integrations/{self.params.integration_name}"
            f"/connectors/-/connectorInstances"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/1p/external/v1.0/legacyFederatedCases:legacyFetchCasesToSync"
        params = {"pageToken": self.params.continuation_token}
        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def patch_federation_cases(self) -> requests.Response:
        """Patch federation cases using legacy API"""
        endpoint = (
            "api/1p/external/v1.0/legacyFederatedCases:legacyBatchPatchFederatedCases"
        )
        headers = {"AppKey": self.params.api_key} if self.params.api_key else None
        payload = {"cases": self.params.cases_payload}

        return self._make_request(
            HttpMethod.POST,
            endpoint,
            json_payload=payload,
            headers=headers,
        )

    def get_workflow_instance_card(self) -> requests.Response:
        """Get workflow instance card using legacy API"""
        endpoint = (
            "api/1p/external/v1.0/legacyPlaybooks:"
            "legacyGetWorkflowInstancesCards?format=camel"
        )
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def pause_alert_sla(self) -> requests.Response:
        """Pause alert sla"""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("case_alerts")[0].get("id")
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/"
            f"alerts/{alert_id}:pauseSla"
        )
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def resume_alert_sla(self) -> requests.Response:
        """Resume alert sla"""
        alert = self.get_case_alerts().json()
        alert_id = alert.get("case_alerts")[0].get("id")
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/"
            f"alerts/{alert_id}:resumeSla"
        )
        payload = {
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_case_overview_details(self) -> requests.Response:
        """Get case overview details"""
        case_id = self.params.case_id
        case_data = {}
        endpoint_case = f"api/1p/external/v1.0/cases/{case_id}?$expand=*"
        endpoint_alert = f"api/1p/external/v1.0/cases/{case_id}/alerts?$expand=*"
        case_data = self._make_request(HttpMethod.GET, endpoint_case).json()
        endpoint_alert_data = self._make_request(HttpMethod.GET, endpoint_alert)
        case_data["alertCards"] = endpoint_alert_data.json()["alerts"]

        return case_data

    def remove_case_tag(self) -> requests.Response:
        """Remove case tag"""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}:removeTag"
        payload = {
            "caseId": self.params.case_id,
            "tag": self.params.tag,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def change_case_description(self) -> requests.Response:
        """Change case description"""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}"
        payload = {"description": self.params.description}
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def set_alert_priority(self) -> requests.Response:
        """Set alert priority"""
        endpoint = (
            "v1alpha/projects/a/locations/b/instances/c/"
            "legacySdk:legacyUpdateAlertPriority"
        )
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "priority": self.params.priority,
            "alertName": self.params.alert_name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_case_score_bulk(self) -> requests.Response:
        """Set case score bulk"""
        endpoint = (
            "v1alpha/projects/a/locations/a/instances/a/legacySdk:legacyUpdateCaseScore"
        )
        payload = {
            "caseScores": [
                {
                    "caseId": self.params.case_id,
                    "score": self.params.score,
                }
            ],
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def get_integration_full_details(self) -> requests.Response:
        """Get integration full details"""
        endpoint = (
            "api/1p/external/v1.0/marketplaceIntegrations/"
            f"{self.params.integration_identifier}"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_id(self) -> requests.Response:
        """Get integration instance details by instance id"""
        endpoint = (
            "api/1p/external/v1.0/integrations/"
            f"{self.params.integration_identifier}/integrationInstances/"
            f"{self.params.instance_id}"
        )

        return self._make_request(HttpMethod.GET, endpoint)

    def get_integration_instance_details_by_name(self) -> SingleJson:
        """Get integration instance details by instance name"""
        endpoint = (
            "api/1p/external/v1.0/integrations/"
            f"{self.params.integration_identifier}/integrationInstances"
        )
        query_params = {
            "filter": f'displayName="{self.params.instance_display_name}"'
        }

        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_users_profile(self) -> requests.Response:
        """Get users profile"""
        endpoint = "api/1p/external/v1.0/legacySoarUsers"
        query_params = {"filter": f'displayName="{self.params.display_name}"'}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_alerts(self) -> requests.Response:
        """Get case alerts"""

        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}/caseAlerts"
        query_params: dict[str, str] = {}
        if self.params.alert_identifier is not None:
            query_params = {"filter": f'identifier="{self.params.alert_identifier}"'}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_investigator_data(self) -> requests.Response:
        """Get investigator data"""
        case_id = self.params.case_id
        alert_data = self.get_alert_id_by_alert_identifier()
        if alert_data.status_code == 204:
            setattr(alert_data, "_content", b"{}")
            return alert_data

        alert_id = alert_data.json()["items"][0].get("id")
        endpoint = (
            f"api/1p/external/v1.0/cases/{case_id}/alerts/{alert_id}/"
            "involvedEvents:formatted"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_alert_id_by_alert_identifier(self) -> requests.Response:
        """Get alert id by alert identifier"""
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/alerts"
        )
        query_params = {
            "filter": f"identifier=\"{self.params.alert_identifier}\""
        }
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    # TODO : Not avialable in 1p so we will implement when api avialble
    def remove_entities_from_custom_list(self) -> requests.Response:
        """Remove entities from custom list"""
        endpoint = "api/external/v1/sdk/RemoveEntitiesFromCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    # TODO : Not avialable in 1p so we will implement when api avialble
    def add_entities_to_custom_list(self) -> requests.Response:
        """Add entities to custom list"""
        endpoint = "api/external/v1/sdk/AddEntitiesToCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_traking_list_record(self) -> requests.Response:
        """Get traking list record"""
        endpoint = "api/1p/external/v1/system/settings/customLists"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_traking_list_records_filtered(self) -> requests.Response:
        """Get traking list records filtered"""
        environment = (
            self.params.environment
            if self.params.environment
            else self.chronicle_soar.environment
        )
        endpoint = (
            "api/1p/external/v1/system/settings/customLists?$filter=environments eq "
            f"'[\"{environment}\"]'"
        )

        return self._make_request(HttpMethod.GET, endpoint)

    def execute_bulk_assign(self) -> requests.Response:
        """Execute bulk assign"""
        endpoint = "api/1p/external/v1/cases:executeBulkAssign"
        payload = {
            "casesIds": self.params.case_ids,
            "userName": self.params.user_name
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def execute_bulk_close_case(self) -> requests.Response:
        """Execute bulk close case"""
        endpoint = "api/1p/external/v1/cases:executeBulkClose"
        payload = {
            "casesIds": self.params.case_ids,
            "closeReason": self.params.close_reason,
            "rootCause": self.params.root_cause,
            "closeComment": self.params.close_comment
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_users_profile_cards(self) -> requests.Response:
        """Get users profile cards."""
        endpoint = "api/1p/external/v1.0/legacySoarUsers"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_security_events(self) -> requests.Response:
        """Get security events"""
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/alerts/"
            f"{self.params.alert_id}/involvedEvents:formatted"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def get_entity_cards(self) -> requests.Response:
        """Get entity cards"""
        endpoint = (
            f"api/1p/external/v1.0/cases/{self.params.case_id}/alerts/"
            f"-/involvedEntities:fetchCards"
        )
        return self._make_request(HttpMethod.GET, endpoint)

    def pause_case_sla(
        self, case_id: int, message: str | None = None
    ) -> requests.Response:
        """Send an api request to pause case sla for a given case"""

        endpoint = f"api/1p/external/v1.0/cases/{case_id}:pauseSla"
        request_payload = {"caseId": case_id}
        if message:
            request_payload["message"] = message

        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=request_payload
        )

    def resume_case_sla(self, case_id: int) -> requests.Response:
        """Send an api request to resume case sla for a given case"""

        endpoint = f"api/1p/external/v1.0/cases/{case_id}:resumeSla"
        request_payload = {"caseId": case_id}
        return self._make_request(
            HttpMethod.POST, endpoint, json_payload=request_payload
        )

    def rename_case(self) -> requests.Response:
        """Rename case"""
        endpoint = f"api/1p/external/v1.0/cases/{self.params.case_id}"
        payload = {"displayName": self.params.case_title}
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def add_comment_to_entity(self) -> requests.Response:
        """Add comment to entity"""
        endpoint = "api/1p/external/v1/uniqueEntities:addNote"
        payload = {
            "author": self.params.author,
            "content": self.params.content,
            "entityIdentifier": self.params.entity_identifier,
            "entityType": self.params.entity_type,
            "entityEnvironment": self.params.entity_environment
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def assign_case_to_user(self) -> requests.Response:
        """Assign case to user"""
        endpoint = "api/1p/external/v1.0/cases:executeBulkAssign"
        payload = {
            "casesIds": [self.params.case_id],
            "userName": self.params.assign_to
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_email_template(self) -> requests.Response:
        """Get email template"""
        endpoint = "api/1p/external/v1/system/settings/emailTemplates"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_siemplify_user_details(self) -> requests.Response:
        """Get siemplify user details"""
        endpoint = "api/1p/external/v1.0/legacySoarUsers"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_domain_alias(self) -> requests.Response:
        """Get domain alias"""
        endpoint = "api/1p/external/v1/system/settings/domains"
        return self._make_request(HttpMethod.GET, endpoint)
